CREATE TABLE poetry_high (
id BIGINT NOT NULL PRIMARY KEY,
author VARCHAR(255) DEFAULT NULL,
dynasty VARCHAR(255) DEFAULT NULL,
level VARCHAR(255) DEFAULT NULL,
title VARCHAR(255) DEFAULT NULL,
type VARCHAR(255) DEFAULT NULL,
content VARCHAR(255) DEFAULT NULL
);
SET NAMES 'utf8mb4';


INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (1, '观沧海', '东汉', '曹操', 'OTHERS', 'HIGH', '东临碣石，以观沧海。水何澹澹，山岛竦峙。树木丛生，百草丰茂。秋风萧瑟，洪波涌起。日月之行，若出其中;星汉灿烂，若出其里。幸甚至哉，歌以咏志。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (2, '饮酒', '东晋', '陶渊明', 'FIVE_WORDS', 'HIGH', '结庐在人境，而无车马喧。问君何能尔，心远地自偏。采菊东篱下，悠然见南山。山气日夕佳，飞鸟相与还。此中有真意，欲辨已忘言。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (3, '送杜少府之任蜀川', '唐', '王勃', 'FIVE_WORDS', 'HIGH', '城阙辅三秦，风烟望五津。与君离别意，同是宦游人。海内存知己，天涯若比邻。无为在歧路，儿女共沾巾。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (4, '相见欢', '五代南唐', '李煜', 'OTHERS', 'HIGH', '无言独上西楼，月如钩。寂寞梧桐深院锁清秋。剪不断，理还乱，是离愁。别是一般滋味在心头。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (5, '春望', '唐', '杜甫', 'FIVE_WORDS', 'HIGH', '国破山河在，城春草木深。感时花溅泪，恨别鸟惊心。烽火连三月，家书抵万金。白头搔更短，浑欲不胜簪。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (6, '望岳', '唐', '杜甫', 'FIVE_WORDS', 'HIGH', '岱宗夫如何，齐鲁青未了。造化钟神秀，阴阳割昏晓。荡胸生曾云，决眦入归鸟。会当凌绝顶，一览众山小。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (7, '观刈麦', '唐', '白居易', 'FIVE_WORDS', 'HIGH', '田家少闲月，五月人倍忙。夜来南风起，小麦覆陇黄。妇姑荷箪食，童稚携壶浆。相随饷田去，丁壮在南冈。足蒸暑土气，背灼炎天光。力尽不知热，但惜夏日长。复有贫妇人，抱子在其旁。右手秉遗穗，左臂悬敝筐。听其相顾言，闻者为悲伤。家田输税尽，拾此充饥肠。今我何功德，曾不事农桑。吏禄三百石，岁晏有余粮。念此私自愧，尽日不能忘。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (8, '闻王昌龄左迁龙标遥有此寄', '唐', '李白', 'SEVEN_WORDS', 'HIGH', '杨花落尽子规啼，闻道龙标过五溪。我寄愁心与明月，随君直到夜郎西!');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (9, '登飞来峰', '北宋', '王安石', 'SEVEN_WORDS', 'HIGH', '飞来山上千寻塔，闻说鸡鸣见日升。不畏浮云遮望眼，自缘身在最高层。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (10, '早春呈水部张十八员外', '唐', '韩愈', 'SEVEN_WORDS', 'HIGH', '天街小雨润如酥，草色遥看近却无。最是一年春好处，绝胜烟柳满皇都。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (11, '关雎', '周朝', '佚名', 'OTHERS', 'HIGH', '关关雎鸠，在河之洲。窈窕淑女，君子好逑。求之不得，寤寐思服。悠哉悠哉，辗转反侧。参差荇菜，左右采之。窈窕淑女，琴瑟友之。参差荇菜，左右芼之。窈窕淑女，钟鼓乐之。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (12, '蒹葭', '周朝', '佚名', 'OTHERS', 'HIGH', '蒹葭苍苍，白露为霜。所谓伊人，在水一方，溯洄从之，道阻且长。溯游从之，宛在水中央。蒹葭萋萋，白露未晞。所谓伊人，在水之湄。溯洄从之，道阻且跻[ji]。溯游从之，宛在水中坻。蒹葭采采，白露未已。所谓伊人，在水之涘。溯洄从之，道阻且右。溯游从之，宛在水中沚。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (13, '次北固山下', '唐', '王湾', 'FIVE_WORDS', 'HIGH', '客路青山外，行舟绿水前。潮平两岸阔，风正一帆悬。海日生残夜，江春入旧年。乡书何处达，归雁洛阳边。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (14, '使至塞上', '唐', '王维', 'FIVE_WORDS', 'HIGH', '单车欲问边，属国过居延。征蓬出汉塞，归雁入胡天。大漠孤烟直，长河落日圆。萧关逢候骑，都护在燕然。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (15, '行路难', '唐', '李白', 'OTHERS', 'HIGH', '金樽清酒斗十千，玉盘珍羞直万钱。停杯投箸不能食，拔剑四顾心茫然。欲渡黄河冰塞川，将登太行雪满山。闲来垂钓碧溪上，忽复乘舟梦日边。行路难！行路难！多歧路，今安在？长风破浪会有时，直挂云帆济沧海。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (16, '茅屋为秋风所破歌', '唐', '杜甫', 'OTHERS', 'HIGH', '八月秋高风怒号，卷我屋上三重茅。茅飞渡江洒江郊，高者挂罥长林梢，下者飘转沉塘坳。南村群童欺我老无力，忍能对面为盗贼。公然抱茅入竹去，唇焦口燥呼不得，归来倚杖自叹息。俄倾风定云墨色，秋天漠漠向昏黑。布衾多年冷似铁，娇儿恶卧踏里裂。床头屋漏无干处，雨脚如麻未断绝。自经丧乱少睡眠，长夜沾湿何由彻！安得广厦千万间，大庇天下寒士俱欢颜，风雨不动安如山！呜呼！何时眼前突兀见此屋，吾庐独破受冻死亦足！');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (17, '白雪歌送武判官归京', '唐', '岑参', 'SEVEN_WORDS', 'HIGH', '北风卷地白草折，胡天八月即飞雪。忽如一夜春风来，千树万树梨花开。散入珠帘湿罗幕，狐裘不暖锦衾薄。将军角弓不得控，都护铁衣冷难着。瀚海阑干百丈冰，愁云惨淡万里凝。中军置酒饮归客，胡琴琵琶与羌笛。纷纷暮雪下辕门，风掣红旗冻不翻。轮台东门送君去，去时雪满天山路。山回路转不见君，雪上空留马行处。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (18, '酬乐天扬州初逢席上见赠', '唐', '刘禹锡', 'SEVEN_WORDS', 'HIGH', '巴山楚水凄凉地，二十三年弃置身。怀旧空吟闻笛赋，到乡翻似烂柯人。沉舟侧畔千帆过，病树前头万木春。今日听君歌一曲，暂凭杯酒长精神。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (19, '钱塘湖春行', '唐', '白居易', 'SEVEN_WORDS', 'HIGH', '孤山寺北贾亭西，水面初平云脚低。几处早莺争暖树，谁家新燕啄春泥。乱花渐欲迷人眼，浅草才能没马蹄。最爱湖东行不足，绿杨阴里白沙堤。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (20, '雁门太守行', '唐', '李贺', 'SEVEN_WORDS', 'HIGH', '黑云压城城欲摧，甲光向日金鳞开。角声满天秋色里，塞上燕脂凝夜紫。半卷红旗临易水，霜重鼓寒声不起。报君黄金台上意，提携玉龙为君死。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (21, '赤壁', '唐', '杜牧', 'SEVEN_WORDS', 'HIGH', '折戟沉沙铁未销，自将磨洗认前朝。东风不与周郎便，铜雀春深锁二乔');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (22, '泊秦淮', '唐', '杜牧', 'SEVEN_WORDS', 'HIGH', '烟笼寒水月笼沙，夜泊秦淮近酒家。商女不知亡国恨，隔江犹唱后庭花。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (23, '夜雨寄北', '唐', '李商隐', 'SEVEN_WORDS', 'HIGH', '君问归期未有期，巴山夜雨涨秋池。何当共剪西窗烛，却话巴山夜雨时。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (24, '无题', '唐', '李商隐', 'SEVEN_WORDS', 'HIGH', '相见时难别亦难，东风无力百花残。春蚕到死丝方尽，蜡炬成灰泪始干。晓镜但愁云鬓改，夜吟应觉月光寒。蓬山此去多无路，青鸟殷勤为探看。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (25, '过华清宫', '唐', '杜牧', 'SEVEN_WORDS', 'HIGH', '长安回望绣成堆，山顶千门次第开。一骑红尘妃子笑，无人知是荔枝来。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (26, '书愤', '宋', '陆游', 'SEVEN_WORDS', 'HIGH', '早岁那知世事艰，中原北望气如山。楼船夜雪瓜洲渡！铁马秋风大散关。塞上长城空自许，镜中衰鬓已先斑。出师一表真名世，千载谁堪伯仲间！');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (27, '虞美人', '唐', '李煜', 'OTHERS', 'HIGH', '春花秋月何时了？往事知多少。小楼昨夜又东风，故国不堪回首月明中。雕栏玉砌应犹在，只是朱颜改。问君能有几多愁？恰似一江春水向东流。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (28, '雨霖铃', '宋', '柳永', 'OTHERS', 'HIGH', '寒蝉凄切，对长亭晚，骤雨初歇。都门帐饮无绪，留恋处，兰舟催发。执手相看泪眼，竟无语凝噎。念去去，千里烟波，暮霭沉沉楚天阔。多情自古伤离别，更那堪冷落清秋节！今宵酒醒何处？杨柳岸晓风残月。此去经年，应是良辰好景虚设。便纵有千种风情，更与何人说！');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (29, '声声慢', '宋', '李清照', 'OTHERS', 'HIGH', '寻寻觅觅，冷冷清清，凄凄惨惨戚戚。乍暖还寒时候，最难将息。三杯两盏淡酒，怎敌他，晚来风急？雁过也，正伤心，却是旧时相识。满地黄花堆积。憔悴损，如今有谁堪摘？守着窗儿，独自怎生得黑？梧桐更兼细雨，到黄昏，点点滴滴。这次第，怎一个愁字了得！');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (30, '水调歌头·明月几时有', '宋', '苏轼', 'OTHERS', 'HIGH', '丙辰中秋，欢饮达旦，大醉，作此篇，兼怀子由。明月几时有？把酒问青天。不知天上宫阙，今夕是何年。我欲乘风归去，又恐琼楼玉宇，高处不胜寒。起舞弄清影，何似在人间。转朱阁，低绮户，照无眠。不应有恨，何事长向别时圆？人有悲欢离合，月有阴晴圆缺，此事古难全。但愿人长久，千里共婵娟。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (31, '短歌行', '汉乐府', '曹操', 'OTHERS', 'HIGH', '对酒当歌，人生几何？譬如朝露，去日苦多。慨当以慷，忧思难忘。何以解忧？唯有杜康。青青子衿，悠悠我心。但为君故，沉吟至今。呦呦鹿鸣，食野之苹。我有嘉宾，鼓瑟吹笙。明明如月，何时可掇？忧从中来，不可断绝。越陌度阡，枉用相存。契阔谈讌，心念旧恩。月明星稀，乌鹊南飞。绕树三匝，何枝可依？山不厌高，海不厌深。周公吐哺，天下归心。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (32, '山居秋暝', '唐', '王维', 'FIVE_WORDS', 'HIGH', '空山新雨后，天气晚来秋。明月松间照，清泉石上流。竹喧归浣女，莲动下渔舟。随意春芳歇，王孙自可留。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (33, '己亥杂诗', '清', '龚自珍', 'SEVEN_WORDS', 'HIGH', '浩荡离愁白日斜，吟鞭东指即天涯。落红不是无情物，化作春泥更护花。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (34, '登高', '唐', '杜甫', 'SEVEN_WORDS', 'HIGH', '风急天高猿啸哀，渚清沙白鸟飞回。无边落木萧萧下，不尽长江滚滚来。万里悲秋常作客，百年多病独登台。艰难苦恨繁霜鬓，潦倒新停浊酒杯。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (35, '迢迢牵牛星', '汉乐府', '佚名', 'FIVE_WORDS', 'HIGH', '迢迢牵牛星，皎皎河汉女。纤纤擢素手，札札弄机杼。终日不成章，泣涕零如雨。河汉清且浅，相去复几许？盈盈一水间，脉脉不得语。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (36, '诗经·氓', '周朝', '佚名', 'OTHERS', 'HIGH', '氓之蚩蚩，抱布贸丝。匪来贸丝，来即我谋。送子涉淇，至于顿丘。匪我愆期，子无良媒。将子无怒，秋以为期。乘彼垝垣，以望复关。不见复关，泣涕涟涟。既见复关，载笑载言。尔卜尔筮，体无咎言。以尔车来，以我贿迁。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (37, '菩萨蛮·人人尽说江南好', '唐', '韦庄', 'OTHERS', 'HIGH', '人人尽说江南好，游人只合江南老。春水碧于天，画船听雨眠。垆边人似月，皓腕凝霜雪。未老莫还乡，还乡须断肠。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (38, '扬州慢', '南宋', '姜夔', 'OTHERS', 'HIGH', '淮左名都，竹西佳处，解鞍少驻初程。过春风十里，尽荠麦青青。自胡马窥江去后，废池乔木，犹厌言兵。渐黄昏，清角吹寒，都在空城。杜郎俊赏，算而今重到须惊。纵豆蔻词工，青楼梦好，难赋深情。二十四桥仍在，波心荡，冷月无声。念桥边红药，年年知为谁生！');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (39, '秋兴八首（其一）', '唐', '杜甫', 'SEVEN_WORDS', 'HIGH', '玉露凋伤枫树林，巫山巫峡气萧森。江间波浪兼天涌，塞上风云接地阴。丛菊两开他日泪，孤舟一系故园心。寒衣处处催刀尺，白帝城高急暮砧。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (40, '咏怀古迹（其三）', '唐', '杜甫', 'SEVEN_WORDS', 'HIGH', '群山万壑赴荆棘，生长明妃尚有村。一去紫台连朔漠，独留青冢向黄昏。画图省识春风面，环佩空归月夜魂。千载琵琶作胡语，分明怨恨曲中论。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (41, '过零丁洋', '南宋', '文天祥', 'SEVEN_WORDS', 'HIGH', '辛苦遭逢起一经，干戈寥落四周星。山河破碎风飘絮，身世浮沉雨打萍。惶恐滩头说惶恐，零丁洋里叹零丁。人生自古谁无死？留取丹心照汗青。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (42, '天净沙秋思', '元', '马致远', 'OTHERS', 'HIGH', '枯藤老树昏鸦，小桥流水人家，古道西风瘦马。夕阳西下，断肠人在天涯');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (43, '山坡羊·潼关怀古', '元', '张养浩', 'OTHERS', 'HIGH', '峰峦如聚，波涛如怒，山河表里潼关路。望西都，意踌躇。伤心秦汉经行处，宫阙万间都做了土。兴，百姓苦。亡，百姓苦。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (44, '客至', '唐', '杜甫', 'SEVEN_WORDS', 'HIGH', '舍南舍北皆春水，但见群鸥日日来。花径不曾缘客扫，蓬门今始为君开。盘飧市远无兼味，樽酒家贫只旧醅。肯与邻翁相对饮，隔篱呼取尽余杯。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (45, '蜀相', '唐', '杜甫', 'SEVEN_WORDS', 'HIGH', '丞相祠堂何处寻？锦官城外柏森森。映阶碧草自春色，隔叶黄鹂空好音。三顾频烦天下计，两朝开济老臣心。出师未捷身先死，长使英雄泪满襟。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (46, '短歌行', '汉乐府', '曹操', 'OTHERS', 'HIGH', '对酒当歌，人生几何？譬如朝露，去日苦多。慨当以慷，忧思难忘。何以解忧？唯有杜康。青青子衿，悠悠我心。但为君故，沉吟至今。呦呦鹿鸣，食野之苹。我有嘉宾，鼓瑟吹笙。明明如月，何时可掇？忧从中来，不可断绝。越陌度阡，枉用相存。契阔谈讌，心念旧恩。月明星稀，乌鹊南飞。绕树三匝，何枝可依？山不厌高，海不厌深。周公吐哺，天下归心。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (47, '夜归鹿门歌', '唐', '孟浩然', 'SEVEN_WORDS', 'HIGH', '山寺钟鸣昼已昏，渔梁渡头争渡喧。人随沙路向江村，余亦乘舟归鹿门。鹿门月照开烟树，忽到庞公栖隐处。岩扉松径长寂寥，惟有幽人夜来去。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (48, '登岳阳楼', '唐', '杜甫', 'FIVE_WORDS', 'HIGH', '昔闻洞庭水，今上岳阳楼。吴楚东南坼，乾坤日夜浮。亲朋无一字，老病有孤舟。戎马关山北，凭轩涕泗流。');
INSERT INTO `poetry_high` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (49, '一剪梅', '宋', '李清照', 'OTHERS', 'HIGH', '红耦香残玉蕈秋，轻解罗裳，独上兰舟。云中谁寄锦书来？雁字回时，月满西楼。花自飘零水自流。一种相思，两处闲愁。此情无计可消除。才下眉头，却上心头。');

ALTER TABLE poetry AUTO_INCREMENT = 124;
INSERT INTO poetry (author, dynasty, level, title, type, content)
SELECT author, dynasty, level, title, type, content FROM poetry_high;
