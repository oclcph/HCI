# 使用方法

**请先拉取远程仓库名为ylh的分支**，我对后端数据库部分做了**索引自增**的修改。

我是在命令行运行mysql的，已经可以成功导入并使用postman测试后端接口后没有问题，方法供大家参考。

1. 命令行登录mysql，并创建hci数据库，运行后端，并从命令行进入hci数据库

``` mysql
mysql -u root -p
use hci
```

2. 按照`poetry_low.sql`, `poetry_mid.sql`, `poetry_high.sql`, `sentence_low.sql`, `sentence_mid.sql`, `sentence_high.sql`的顺序将数据导入数据库中。例如：命令行运行

``` mysql
source poetry_low.sql     # source后需要跟.sql的文件路径
```

3. 最后运行`source delete.sql`清除多余数据库，只保留poetry和sentence

> 如果查询时命令行出现中文乱码，怀疑是cmd和mysql编码不一致导致，建议使用postman测试后端接口是否可用，不过我测试过了没问题



