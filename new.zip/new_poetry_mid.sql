CREATE TABLE poetry_mid (
id BIGINT NOT NULL PRIMARY KEY,
author VARCHAR(255) DEFAULT NULL,
dynasty VARCHAR(255) DEFAULT NULL,
level VARCHAR(255) DEFAULT NULL,
title VARCHAR(255) DEFAULT NULL,
type VARCHAR(255) DEFAULT NULL,
content VARCHAR(255) DEFAULT NULL
);
SET NAMES 'utf8mb4';

INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (1, '龟虽寿', '东汉', '曹操', 'OTHERS', 'MID', '神龟虽寿，犹有竟时。螣蛇乘雾，终为土灰。老骥伏枥，志在千里。烈士暮年，壮心不已。盈缩之期，不但在天。养怡之福，可得永年。幸甚至哉，歌以咏志。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (2, '过故人庄', '唐', '孟浩然', 'FIVE_WORDS', 'MID', '故人具鸡黍，邀我至田家。绿树村边合，青山郭外斜。开轩面场圃，把酒话桑麻。待到重阳日，还来就菊花。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (3, '题破山寺后禅院', '唐', '常建', 'FIVE_WORDS', 'MID', '清晨入古寺，初日照高林。曲径通幽处，禅房花木深。山光悦鸟性，潭影空人心。万籁此都寂，但余钟磬音。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (4, '闻王昌龄左迁龙标遥有此寄', '唐', '李白', 'SEVEN_WORDS', 'MID', '杨花落尽子规啼，闻道龙标过五溪。我寄愁心与明月，随君直到夜郎西。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (5, '夜雨寄北', '唐', '李商隐', 'SEVEN_WORDS', 'MID', '君问归期未有期，巴山夜雨涨秋池。何当共剪西窗烛，却话巴山夜雨时。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (6, '泊秦淮', '唐', '杜牧', 'SEVEN_WORDS', 'MID', '烟笼寒水月笼沙，夜泊秦淮近酒家。商女不知亡国恨，隔江犹唱后庭花。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (7, '浣溪沙', '宋', '晏殊', 'SEVEN_WORDS', 'MID', '一曲新词酒一杯。去年天气旧亭台。夕阳西下几时回?无可奈何花落去。似曾相识燕归来。小园香径独徘徊。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (8, '过松源晨炊漆公店', '南宋', '杨万里', 'SEVEN_WORDS', 'MID', '莫言下岭便无难，赚得行人空喜欢;正入万山圈子里，一山放过一山拦。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (9, '如梦令', '南宋', '李清照', 'OTHERS', 'MID', '常记溪亭日暮，沉醉不知归路。兴尽晚回舟，误入藕花深处。争渡，争渡，惊起一滩鸥鹭。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (10, '观书有感', '南宋', '朱熹', 'SEVEN_WORDS', 'MID', '半亩方塘一鉴开，天光云影共徘徊。问渠那得清如许?为有源头活水来。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (11, '山中杂诗', '南朝', '吴均', 'FIVE_WORDS', 'MID', '山际见来烟，竹中窥落日。鸟向檐上飞，云从窗里出。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (12, '竹里馆', '唐', '王维', 'FIVE_WORDS', 'MID', '独坐幽篁里，弹琴复长啸。深林人不知，明月来相照。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (13, '峨眉山月歌', '唐', '李白', 'SEVEN_WORDS', 'MID', '峨眉山月半轮秋，影入平羌江水流。夜发清溪向三峡，思君不见下渝州。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (14, '春夜洛城闻笛', '唐', '李白', 'SEVEN_WORDS', 'MID', '谁家玉笛暗飞声，散入春风满洛城。此夜曲中闻折柳，何人不起故园情。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (15, '逢入京使', '唐', '岑参', 'SEVEN_WORDS', 'MID', '故园东望路漫漫，双袖龙钟泪不干。马上相逢无纸笔，凭君传语报平安。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (16, '滁州西涧', '唐', '韦应物', 'SEVEN_WORDS', 'MID', '独怜幽草涧边生，上有黄鹂深树鸣。春潮带雨晚来急，野渡无人舟自横。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (17, '江南逢李龟年', '唐', '杜甫', 'SEVEN_WORDS', 'MID', '岐王宅里寻常见，崔九堂前几度闻。正是江南好风景，落花时节又逢君。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (18, '送灵澈上人', '唐', '刘长卿', 'FIVE_WORDS', 'MID', '苍苍竹林寺，杳杳钟声晚。荷笠带斜阳，青山独归远。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (19, '约客', '南宋', '赵师秀', 'SEVEN_WORDS', 'MID', '黄梅时节家家雨，青草池塘处处蛙。有约不来过夜半，闲敲棋子落灯花。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (20, '论诗', '清', '赵翼', 'SEVEN_WORDS', 'MID', '李杜诗篇万口传，至今已觉不新鲜。江山代有才人出，各领风骚数百年。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (21, '长歌行', '汉乐府', '佚名', 'FIVE_WORDS', 'MID', '青青园中葵，朝露待日晞。阳春布德泽，万物生光辉。常恐秋节至，焜黄华叶衰。百川东到海，何时复西归?少壮不努力，老大徒伤悲。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (22, '野望', '唐', '王绩', 'FIVE_WORDS', 'MID', '东皋薄暮望，徙倚欲何依。树树皆秋色，山山唯落晖。牧人驱犊返，猎马带禽归。相顾无相识，长歌怀采薇。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (23, '早寒江上有怀', '唐', '孟浩然', 'FIVE_WORDS', 'MID', '木落雁南度，北风江上寒。我家襄水曲，遥隔楚云端。乡泪客中尽，孤帆天际看。迷津欲有问，平海夕漫漫。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (24, '望洞庭湖赠张丞相', '唐', '孟浩然', 'FIVE_WORDS', 'MID', '八月湖水平，涵虚混太清。气蒸云梦泽，波撼岳阳城。欲济无舟楫，端居耻圣明。坐观垂钓者，徒有羡鱼情。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (25, '黄鹤楼', '唐', '崔颢', 'SEVEN_WORDS', 'MID', '昔人已乘黄鹤去，此地空余黄鹤楼。黄鹤一去不复返，白云千载空悠悠。晴川历历汉阳树，芳草萋萋鹦鹉洲。日暮乡关何处是？烟波江上使人愁。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (26, '送友人', '唐', '李白', 'FIVE_WORDS', 'MID', '青山横北郭，白水绕东城。此地一为别，孤蓬万里征。浮云游子意，落日故人情。挥手自兹去，萧萧班马鸣。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (27, '秋词', '唐', '刘禹锡', 'SEVEN_WORDS', 'MID', '自古逢秋悲寂寥，我言秋日胜春朝。晴空一鹤排云上，便引诗情到碧霄。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (28, '鲁山山行', '北宋', '梅尧臣', 'FIVE_WORDS', 'MID', '适与野情惬，千山高复低。好峰随处改，幽径独行迷。霜落熊升树，林空鹿饮溪。人家在何许，云外一声鸡。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (29, '浣溪沙', '北宋', '苏轼', 'SEVEN_WORDS', 'MID', '兰下兰芽短浸溪，松间沙路净无泥，潇潇暮雨子规啼。谁道人生无再少？门前流水尚能西！休将白发唱黄鸡。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (30, '十一月四日风雨大作', '南宋', '陆游', 'SEVEN_WORDS', 'MID', '僵卧孤村不自哀，尚思为国戍轮台。夜阑卧听风吹雨，铁马冰河入梦来。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (31, '赠从弟', '东汉', '刘桢', 'FIVE_WORDS', 'MID', '亭亭山上松，瑟瑟谷中风。风声一何盛，松枝一何劲。冰霜正惨凄，终岁常端正。岂不罹凝寒，松柏有本性。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (32, '送杜少府之任蜀州', '唐', '王勃', 'FIVE_WORDS', 'MID', '城阙辅三秦，风烟望五津。与君离别意，同是宦游人。海内存知己，天涯若比邻。无为在歧路，儿女共沾巾。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (33, '登幽州台歌', '唐', '陈子昂', 'OTHERS', 'MID', '前不见古人，后不见来者。念天地之悠悠，独怆然而涕下。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (34, '送元二使安西', '唐', '王维', 'SEVEN_WORDS', 'MID', '渭城朝雨浥轻尘，客舍青青柳色新。劝君更尽一杯酒，西出阳关无故人。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (35, '宣州谢朓楼饯别校书叔云', '唐', '李白', 'OTHERS', 'MID', '弃我去者，昨日之日不可留；乱我心者，今日之日多烦忧。长风万里送秋雁，对此可以酣高楼。蓬莱文章建安骨，中间小谢又清发。俱怀逸兴壮思飞，欲上青天览明月。抽刀断水水更流，举杯销愁愁更愁。人生在世不称意，明朝散发弄扁舟。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (36, '早春呈水部张十八员外', '唐', '韩愈', 'SEVEN_WORDS', 'MID', '天街小雨润如酥，草色遥看近却无。最是一年春好处，绝胜烟柳满皇都。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (37, '无题', '唐', '李商隐', 'SEVEN_WORDS', 'MID', '相见时难别亦难，东风无力百花残。春蚕到死丝方尽，蜡炬成灰泪始干。晓镜但愁云鬓改，夜吟应觉月光寒。蓬山此去无多路，青鸟殷勤为探看。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (38, '相见欢', '五代南唐', '李煜', 'OTHERS', 'MID', '无言独上西楼，月如钩，寂寞梧桐深院锁清秋。剪不断，理还乱，是离愁，别是一般滋味在心头。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (39, '登飞来峰', '北宋', '王安石', 'SEVEN_WORDS', 'MID', '飞来山上千寻塔，闻说鸡鸣见日升。不畏浮云遮望眼，自缘身在最高层。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (40, '清平乐·村居', '南宋', '辛弃疾', 'OTHERS', 'MID', '茅檐低小，溪上青青草。醉里吴音相媚好，白发谁家翁媪？大儿锄豆溪东，中儿正织鸡笼。最喜小儿亡赖，溪头卧剥莲蓬。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (41, '观刈麦', '唐', '白居易', 'FIVE_WORDS', 'MID', '田家少闲月，五月人倍忙。夜来南风起，小麦覆陇黄。妇姑荷箪食，童稚携壶浆。相随饷田去，丁壮在南冈。足蒸暑土气，背灼炎天光。力尽不知热，但惜夏日长。复有贫妇人，抱子在其旁。右手秉遗穗，左臂悬敝筐。听其相顾言，闻者为悲伤。家田输税尽，拾此充饥肠。今我何功德，曾不事农桑。吏禄三百石，岁晏有余粮。念此私自愧，尽日不能忘。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (42, '月夜', '唐', '刘方平', 'SEVEN_WORDS', 'MID', '更深月色半人家，北斗阑干南斗斜。今夜偏知春气暖，虫声新透绿窗纱。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (43, '商山早行', '唐', '温庭筠', 'FIVE_WORDS', 'MID', '晨起动征铎，客行悲故乡。鸡声茅店月，人迹板桥霜。槲叶落山路，枳花照驿墙。因思杜陵梦，凫雁满回塘。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (44, '卜算子·咏梅', '南宋', '陆游', 'OTHERS', 'MID', '驿外断桥边，寂寞开无主。已是黄昏独自愁，更著风和雨。无意苦争春，一任群芳妒。零落成泥碾作尘，只有香如故。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (45, '破阵子', '宋', '晏殊', 'OTHERS', 'MID', '燕子来时新社，梨花落后清明。池上碧苔三四点，叶底黄鹂一两声，日长飞絮轻。巧笑东邻女伴，采桑径里逢迎。疑怪昨宵春梦好，元是今朝斗草赢，笑从双脸生。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (46, '浣溪沙', '宋', '苏轼', 'SEVEN_WORDS', 'MID', '簌簌衣巾落枣花，村南村北响缲车。牛衣古柳卖黄瓜。酒困路长惟欲睡，日高人渴漫思茶。敲门试问野人家。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (47, '醉花阴', '宋', '李清照', 'OTHERS', 'MID', '薄雾浓云愁永昼，瑞脑消金兽。佳节又重阳，玉枕纱厨，半夜凉初透。东篱把酒黄昏后，有暗香盈袖。莫道不消魂，帘卷西风，人比黄花瘦。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (48, '南乡子·登京口北固亭有怀', '南宋', '辛弃疾', 'OTHERS', 'MID', '何处望神州？满眼风光北固楼。千古兴亡多少事？悠悠。不尽长江滚滚流。年少万兜鍪，坐断东南战未休。天下英雄谁敌手？曹刘，生子当如孙仲谋。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (49, '山坡羊·骊山怀古', '元', '张养浩', 'OTHERS', 'MID', '骊山四顾，阿房一炬，当时奢侈今何处？只见草萧疏，水萦纡。至今遗恨迷烟树。列国周齐秦汉楚，赢，都变做了土；输，都变做了土。');
INSERT INTO `poetry_mid` (`id`, `title`, `dynasty`, `author`, `type`, `level`, `content`) VALUES (50, '朝天子·咏喇叭', '明', '王磐', 'OTHERS', 'MID', '喇叭，唢呐，曲儿小腔儿大。官船来往乱如麻，全仗你抬声价。军听了军愁，民听了民怕。哪里去辨甚么真共假?眼见的吹翻了这家，吹伤了那家，只吹的水尽鹅飞罢！');

ALTER TABLE poetry AUTO_INCREMENT = 74;
INSERT INTO poetry (author, dynasty, level, title, type, content)
SELECT author, dynasty, level, title, type, content FROM poetry_mid;
